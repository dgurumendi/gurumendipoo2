git add .
git commit -m 'initial commit'
git push origin master --force
