package com.ug.encuesta.repository;

import org.springframework.data.repository.CrudRepository;

import com.ug.encuesta.dominio.Requisito;

public interface RequisitoRepository extends CrudRepository<Requisito, Integer>{

}
